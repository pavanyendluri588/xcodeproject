//
//  ViewController.swift
//  manisaketh
//
//  Created by pavan on 25/10/23.
//  Copyright © 2023 pavan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.passwordtextfieldoutlet.isSecureTextEntry = true
        self.adduserpage_age_slider_outlet.value = 10    }
    
    @IBOutlet weak var usernametextfieldoutlet: UITextField!
  
    
    @IBOutlet weak var passwordtextfieldoutlet: UITextField!
    
    var username_password: [String:String] = [:]
    var name: [String] = []
    var gmail: [String] = []
    var gender:[Int] = []
    var age:[Int] = []
    @IBAction func submitbuttonaction(_ sender: Any) {
        
        if usernametextfieldoutlet.text! == "admin" && passwordtextfieldoutlet.text! == "admin123"{
            self.performSegue(withIdentifier: "mainpagesegue", sender: Any?.self)
        }
        else{
            let action = UIAlertController(title: "Warning", message: "username or password is wrong", preferredStyle: .alert)
            action.addAction(UIAlertAction(title: "RESET", style: .destructive, handler: {action in self.buttonreset()}))
            action.addAction(UIAlertAction(title: "CANCEL", style: .cancel, handler: nil))
            self.present(action,animated: true,completion: nil )
            
            
        }
        
    }
    
    func buttonreset(){
        usernametextfieldoutlet.text = ""
        passwordtextfieldoutlet.text = ""
    }
    
    @IBOutlet weak var adduserpage_username_text_field_outlet: UITextField!
    
    @IBOutlet weak var adduserpage_name_text_field_outlet: UITextField!
    
    @IBOutlet weak var adduserpage_gmail_text_field_outlet: UITextField!
    
    
    
    @IBOutlet weak var adduser_page_password_text_field_outlet: UITextField!
    
    
    @IBOutlet weak var adduserpage_conformation_password_text_field_outlet: UITextField!
    
   
    
    @IBAction func adduserpage_conformation_password_action(_ sender: Any) {
        
        if adduser_page_password_text_field_outlet.text! != adduserpage_conformation_password_text_field_outlet.text!{
            conformation_password_check_result_outlet.backgroundColor = .green
            
        }else{
            conformation_password_check_result_outlet.backgroundColor = .red        }
        
    }
    
    
    
    
    @IBAction func adduserpage_reset_button_action(_ sender: Any) {
        adduserpage_username_text_field_outlet.text = ""
        
          adduserpage_name_text_field_outlet.text = ""
        
        adduserpage_gmail_text_field_outlet.text = ""
        adduser_page_password_text_field_outlet.text = ""
        adduser_page_password_text_field_outlet.text = ""
        adduserpage_age_slider_outlet.value = 10
        
    }
    
    
    @IBOutlet weak var username_check_result_outlet: UILabel!
    
    
    @IBOutlet weak var conformation_password_check_result_outlet: UILabel!
    
    @IBOutlet weak var adduserpage_gender_imageview: UIImageView!
    @IBOutlet weak var gender_switch_outlet: UISwitch!
    
    @IBAction func gender_switch_action(_ sender: Any) {
        let maleimage: UIImage = UIImage(named: "")
        let femaleimage: UIImage = UIImage(named: "")
        if gender_switch_outlet.isOn{
            adduserpage_gender_imageview.image = maleimage
            
        }else{
            adduserpage_gender_imageview.image = femaleimage        }
    }
    
    @IBOutlet weak var adduserpage_age_label_display_outlet: UILabel!
    
    
    @IBOutlet weak var adduserpage_age_slider_outlet: UISlider!
    
    @IBAction func adduserpage_age_slider_action(_ sender: Any) {
        
        adduserpage_age_label_display_outlet.text = String(Int(adduserpage_age_slider_outlet.value))
        
        
    }
    
    
    
    
    
    
    
    
    
    @IBAction func adduserpage_username_check_function_for_sidelabel(_ sender: Any) {
        var username_present_check  = 0
        let username = String(adduserpage_username_text_field_outlet.text!)
        if username.count < 5 {
            username_present_check = 1
        }
        
        for i in username_password.keys{
            if username == i {
                username_present_check = 1
            }
        }
        if username_present_check == 1{
            username_check_result_outlet.backgroundColor = .red
           self.adduserpage_username_correct_or_wrong_check_var = 1
            
        } else{
            adduserpage_username_text_field_outlet.backgroundColor = .green
            self.adduserpage_username_correct_or_wrong_check_var = 0
            
        }
        
    }
    
   var adduserpage_username_correct_or_wrong_check_var = 0
    var adduserpage_password_correct_or_wrong_check_var = 0
    
    
    
    
    
    @IBAction func adduserpage_create_user_button_action(_ sender: Any) {
        var insert = 1
        
        
        
        if insert == 1{
            username_password[usernametextfieldoutlet.text!] = passwordtextfieldoutlet.text!
            name.append(adduserpage_name_text_field_outlet.text!)
            gmail.append(adduserpage_gmail_text_field_outlet.text!)
            age.append(Int(adduserpage_age_slider_outlet.value))
            print("data insertion  and user creation successful")
            
        }
        
        
    }
    

    

    
    
    
    
    
}

