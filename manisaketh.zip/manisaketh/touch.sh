git init
git add .
git remote add  origin  https://gitlab.com/swift7880343/xcodeproject.git
git push -uf origin master
