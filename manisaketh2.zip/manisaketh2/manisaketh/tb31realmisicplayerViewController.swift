//
//  tb31realmisicplayerViewController.swift
//  manisaketh
//
//  Created by pavan on 26/10/23.
//  Copyright © 2023 pavan. All rights reserved.
//

import UIKit
import AVFoundation
class tb31realmisicplayerViewController: UIViewController {
    var catrgory1 = ""
    var title1 = ""
    var director = ""
    var audio_name = ""
    var audio_maximum_time = Float(2.0)
    var animationimages_array: [UIImage] = []
    var player : AVAudioPlayer = AVAudioPlayer()
    override func viewDidLoad() {
        super.viewDidLoad()
        do{
            /*self.audio_name*/
            
            guard var audio_path = Bundle.main.path(forResource:"songs/Mood_Happy_Brham_Darya", ofType:"mp3") else {return }
            print("audio path \(audio_path)")
            
            
            //try player = AVAudioPlayer(contentsOf:URL(fileURLWithPath: audio_path))
            
            
        }catch
        {
            print("error eccoured in audio player")
        }
        
       
        tb31realmusicplayer_imageview__outlet.startAnimating()
        tb31musicplayer_end_time_label_outlet.text = String(audio_maximum_time)
        tb31realmusicplayer_category_label_outlet.text = catrgory1
        tb31realmusicplayer_title_label_outlet.text = title1
        tb31realmusicplayer_director_label_outlet.text = director
        tb31realmusicplayer_imageview__outlet.animationImages = animationimages_array
        tb31realmusicplayer_imageview__outlet.startAnimating()
              // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    
   
    
    
    @IBOutlet weak var tb31realmusicplayer_category_label_outlet: UILabel!
    
    
    
    @IBOutlet weak var tb31realmusicplayer_title_label_outlet: UILabel!
    
    
    
    @IBOutlet weak var tb31realmusicplayer_director_label_outlet: UILabel!
    
    
    
    @IBOutlet weak var tb31realmusicplayer_imageview__outlet: UIImageView!
    

    
    
    
    
    @IBOutlet weak var tb31musicplayer_end_time_label_outlet: UILabel!
    
    
    
   
    
    
    @IBAction func tb31realmusicplayer_play_button_action(_ sender: UIButton) {
        player.play()
    }
    
    
    @IBAction func tb31realmusicplayer_pause_button_action(_ sender: Any) {
        player.pause()
    }
    
    
    
    @IBAction func tb31realmusicplayer_stop_button_action(_ sender: Any) {
        player.stop()
        player.currentTime=0
    }
    
    
    
    @IBAction func tb31realmusicplayer_replay_button_action(_ sender: Any) {
        player.currentTime=0
        player.play()
    }
    
    
    
    
    
    
    
    
    
}
