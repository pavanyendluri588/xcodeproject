//
//  ViewController.swift
//  manisaketh
//
//  Created by pavan on 25/10/23.
//  Copyright © 2023 pavan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //self.passwordtextfieldoutlet.text = "password"
        //self.passwordtextfieldoutlet.enablep.toggle()
        
        
        

           }
    
    
    
    
    @IBAction func unwindonr(_ sender: UIStoryboardSegue){
        print("this is unwinding")
    }
    
    
    
    @IBAction func create_account_button_action(_ sender: Any) {
        performSegue(withIdentifier: "adduserviewsegue", sender: Any?.self)
        
    }
    
    
    @IBOutlet weak var usernametextfieldoutlet: UITextField!
  
    
    @IBOutlet weak var passwordtextfieldoutlet: UITextField!
    
    var username:Set<String> = ["admin"]
    var password:[String] = ["admin123"]
    var name: [String] = ["admin"]
    var gmail: [String] = ["admin@gmail.com"]
    var gender:[Int] = [1]
    var age:[Int] = [20]
    @IBAction func submitbuttonaction(_ sender: Any) {
        self.performSegue(withIdentifier: "mainpagesegue", sender: Any?.self)
        
        print(usernametextfieldoutlet.text!," index at ",username.firstIndex(of: usernametextfieldoutlet.text!))
        /*
            if usernametextfieldoutlet.text! == "admin" && passwordtextfieldoutlet.text! == "admin123"{
            self.performSegue(withIdentifier: "mainpagesegue", sender: Any?.self)
        }
        else{
            let action = UIAlertController(title: "Warning", message: "username or password is wrong", preferredStyle: .alert)
            action.addAction(UIAlertAction(title: "RESET", style: .destructive, handler: {action in self.buttonreset()}))
            action.addAction(UIAlertAction(title: "CANCEL", style: .cancel, handler: nil))
            self.present(action,animated: true,completion: nil )
        
            
        }*/
        
        
    }
    
    func buttonreset(){
        usernametextfieldoutlet.text = ""
        passwordtextfieldoutlet.text = ""
    }
    
    
 
    @IBOutlet weak var adduserpage_username_text_field_outlet: UITextField!
    
    @IBOutlet weak var adduserpage_name_text_field_outlet: UITextField!
    
    @IBOutlet weak var adduserpage_gmail_text_field_outlet: UITextField!
    
    
    
    @IBOutlet weak var adduser_page_password_text_field_outlet: UITextField!
    
    
   
    @IBOutlet weak var adduserpage_conformation_password_text_field_outlet: UITextField!
    
   
    
    
    
    @IBOutlet weak var conformation_password_check_result_outlet: UILabel!
    
    
    
    @IBAction func adduserpage_reset_button_action(_ sender: Any) {
        adduserpage_username_text_field_outlet.text = ""
        
          adduserpage_name_text_field_outlet.text = ""
        
        adduserpage_gmail_text_field_outlet.text = ""
        adduser_page_password_text_field_outlet.text = ""
        adduser_page_password_text_field_outlet.text = ""
        adduserpage_age_slider_outlet.value = 10
        
    }
    
    
    
    
    
    @IBOutlet weak var adduserpage_gender_imageview: UIImageView!
    @IBOutlet weak var gender_switch_outlet: UISwitch!
    
    @IBAction func gender_switch_action(_ sender: Any) {
        let maleimage: UIImage = (UIImage(named: "male_symbol.png"))!
        let femaleimage: UIImage = (UIImage(named: "female_symbol.png"))!
        if gender_switch_outlet.isOn{
            adduserpage_gender_imageview.image = maleimage
            
        }else{
            adduserpage_gender_imageview.image = femaleimage        }
    }
    
    @IBOutlet weak var adduserpage_age_label_display_outlet: UILabel!
    
    
    @IBOutlet weak var adduserpage_age_slider_outlet: UISlider!
    
    @IBAction func adduserpage_age_slider_action(_ sender: Any) {
        
        adduserpage_age_label_display_outlet.text = String(Int(adduserpage_age_slider_outlet.value))
        
        
    }
    
    
    
    @IBOutlet weak var username_check_result_outlet: UILabel!
    
    
    /*
    @IBAction func adduserpage_username_check_function_for_sidelabel(_ sender: Any) {
        var username_present_check  = 0
        let username = String(adduserpage_username_text_field_outlet.text!)
        if username.count < 5 {
            username_present_check = 1
        }
        print(username_password.keys)
        for i in username_password.keys{
            print(i,username)
            if username == i {
                username_present_check = 1
            }
        }
        if username_present_check == 1{
            username_check_result_outlet.backgroundColor = .red
            self.adduserpage_username_correct_or_wrong_check_var = 1
            
        } else{
            username_check_result_outlet.backgroundColor = .green
            self.adduserpage_username_correct_or_wrong_check_var = 0
            
        }
    }
 */
    
    
    

    
   var adduserpage_username_correct_or_wrong_check_var = 0
    var adduserpage_password_correct_or_wrong_check_var = 0
    
    
    
    
    func username_no_in_set_check1(_ username__1:String?)-> Int {
        
        for i in username{
            if i == username__1{
                return 1		
            }
        }
        return 0
    }
    func main_comformaation_passowrd_match_check(_ passowrd_main:String ,_ password_conformation:String) -> Int{
        if passowrd_main == password_conformation{
            return 0
        }else{
            return 1
        }
        
        
    }
    
    @IBAction func adduserpage_create_user_button_action(_ sender: Any) {
        var insert = 0
        
         insert = username_no_in_set_check1(adduserpage_name_text_field_outlet.text!)
        if insert == 1{
            let alert = UIAlertController(title: "Warning", message: "username already exists", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "ok", style: .default, handler: nil))
            alert.addAction(UIAlertAction(title: "cancel", style: .cancel, handler: nil))
            self.present(alert,animated: true,completion: nil)
        }
        
        insert = main_comformaation_passowrd_match_check(adduser_page_password_text_field_outlet.text!,adduserpage_conformation_password_text_field_outlet.text!)
        if insert == 1{
            let alert = UIAlertController(title: "Warning", message: "both passwords doesn't match", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "ok", style: .default, handler: nil))
            alert.addAction(UIAlertAction(title: "cancel", style: .cancel, handler: nil))
            self.present(alert,animated: true,completion: nil)        }
        if insert == 0{
            
                username.insert(adduserpage_name_text_field_outlet.text!)
                password.append(adduser_page_password_text_field_outlet.text!)
            name.append(adduserpage_name_text_field_outlet.text!)
            gmail.append(adduserpage_gmail_text_field_outlet.text!)
                var gender1 = 0
                if gender_switch_outlet.isOn{
                    gender1 = 1
                }
                gender.append(gender1)
                age.append(Int(adduserpage_age_slider_outlet.value))
                print("data insertion  and user creation successful")
            
        }
            
            print(username,password)
            print(name)
            print(gmail)
            print(gender)
            
            
        }
        
        
    }
    

    

    
    
    
    
    


