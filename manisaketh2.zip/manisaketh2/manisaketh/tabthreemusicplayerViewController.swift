//
//  tabthreemusicplayerViewController.swift
//  manisaketh
//
//  Created by pavan on 26/10/23.
//  Copyright © 2023 pavan. All rights reserved.
//

import UIKit

class tabthreemusicplayerViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let realmusicplayerpage_view_comtroller = segue.destination as! tb31realmisicplayerViewController
        realmusicplayerpage_view_comtroller.title1 = sending_title
        realmusicplayerpage_view_comtroller.audio_maximum_time = sending_duration
        realmusicplayerpage_view_comtroller.director = sending_director
        realmusicplayerpage_view_comtroller.catrgory1 = sending_category
        realmusicplayerpage_view_comtroller.audio_name = sending_audio_name
        realmusicplayerpage_view_comtroller.animationimages_array = image_array
        
        
    }
    var sending_title = ""
    var sending_category = ""
    var sending_director = ""
    var sending_audio_name = ""
    var image_array:[UIImage] = []
    var sending_duration=Float(0.0)
    
    var music_categories:[String]=["Pop","Electric","Rock"]
    var music_titles=[["sorry","Blinding Lights","Toxic"],["electric1","e2","e3","e4","e5"],["r1","r2"]]
    var music_director=[["Justin Bieber","weeknd","dpop3"],["delectric1","de2","de3","de4","de5"],["dr1","dr2"]]
    var music_images = [[[UIImage(named: "sorry.jpg")!,UIImage(named: "sorry1.jpg")!,UIImage(named: "sorry2.jpg" )!],[UIImage(named:
        "blindinglights")!,UIImage(named: "blindinglights1.jpg")!,UIImage(named: "blindinglights2.jpg" )!]        ]]
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return music_categories[section]
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return music_categories.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      return music_titles[section].count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        sending_category = music_categories[indexPath.section]
        sending_director = music_director[indexPath.section][indexPath.row]
        sending_duration = Float(100)
        sending_title = music_titles[indexPath.section][indexPath.row]
        image_array = music_images[0][1]
        sending_audio_name = "Mood_Happy_Brham_Darya"
        
        performSegue(withIdentifier:"realmusicplayersegue", sender: Any?.self)
        
        print("segue has been performed")
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell :mycustomtableviewcell = tableView.dequeueReusableCell(withIdentifier: "musicplayercell" , for: indexPath) as! mycustomtableviewcell
       // cell.music
        cell.musicplayer_tableviewcell_imageview.image = UIImage(named:"male_symbol")
        cell.musicplayer_tableviewcell_title_label?.text = music_titles[indexPath.section][indexPath.row]
        cell.musicplayer_tableviewcell_directorname_label?.text = music_director[indexPath.section][indexPath.row]
        return cell
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
    
    
    
  
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
