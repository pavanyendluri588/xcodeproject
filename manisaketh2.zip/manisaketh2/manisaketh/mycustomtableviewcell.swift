//
//  mycustomtableviewcell.swift
//  manisaketh
//
//  Created by pavan on 26/10/23.
//  Copyright © 2023 pavan. All rights reserved.
//

import UIKit

class mycustomtableviewcell: UITableViewCell {

    
    
    
    
    
    @IBOutlet weak var musicplayer_tableviewcell_imageview: UIImageView!
    
    
    @IBOutlet weak var musicplayer_tableviewcell_title_label: UILabel!
    
    @IBOutlet weak var musicplayer_tableviewcell_directorname_label: UILabel!
    
  
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
