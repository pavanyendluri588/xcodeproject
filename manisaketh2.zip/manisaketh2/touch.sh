git init
git add .
git remote set-url origin "https://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@github.com/pavanyendluri588/xcodeproject.git"
git commit -m "25-10-23 upload"
Git push origin master
