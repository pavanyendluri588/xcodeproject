//
//  finalViewController.swift
//  Jithendra
//
//  Created by pavan on 05/11/23.
//  Copyright © 2023 lpu. All rights reserved.
//

import UIKit

class finalViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        
        finalpage_name_label_outlet.text = String(pdata)
        finalpage_income_label_outlet.text = String(p1!)
        finalpage_balance_label_outlet.text = String(k)
        finalpage_expenditure_ammount_label_outlet.text = String(f1!)
        finalpage_previouspage_name_label_outlet.text = previouspagename
    }
    
    var previouspagename :String = ""
    
    @IBOutlet weak var finalpage_name_label_outlet: UILabel!
    
    
    @IBOutlet weak var finalpage_income_label_outlet: UILabel!
    
    
    @IBOutlet weak var finalpage_previouspage_name_label_outlet: UILabel!
    
    
    @IBOutlet weak var finalpage_expenditure_ammount_label_outlet: UILabel!
    
    
    
    @IBOutlet weak var finalpage_balance_label_outlet: UILabel!
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
