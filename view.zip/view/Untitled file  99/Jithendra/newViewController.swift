//
//  newViewController.swift
//  Jithendra
//
//  Created by Student on 27/10/23.
//  Copyright © 2023 lpu. All rights reserved.
//

import UIKit
import AVFoundation
var pdata = String()

class newViewController: UIViewController {
    var player :AVAudioPlayer = AVAudioPlayer()
    override func viewDidLoad() {
        super.viewDidLoad()
        l1.text = pdata
        
        
        do {
            var audiopath = Bundle.main.path(forResource: "welcome", ofType: "mp3")
            player = try AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audiopath!) as URL)
        }
        catch{
            print("error in shoping audio player")
        }
        player.play()
        
        // Do any additional setup after loading the view.
    }
    

    @IBOutlet weak var l1: UILabel!
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
}
