//
//  expViewController.swift
//  Jithendra
//
//  Created by Student on 27/10/23.
//  Copyright © 2023 lpu. All rights reserved.
//

import UIKit

class expViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        var m : balViewController = segue.destination as! balViewController
//
//    }
    
    @IBOutlet weak var u11: UITextField!
    
    @IBOutlet weak var exp: UITextField!
    var  k = Float()
    
    @IBAction func funct(_ sender: Any) {
      
        
        var  p1 = Float(u11.text!)
       var  f1 = Float(exp.text!)
        
        if p1! < f1!{
            
            let alert1 = UIAlertController(title: "Warning", message: "Expence is greater than Income", preferredStyle: .alert)
            alert1.addAction(UIAlertAction(title: "cancel", style: .cancel, handler: nil))
            alert1.addAction(UIAlertAction(title: "ok", style: .default ,handler: nil))
            self.present(alert1,animated: true,completion: nil);
            
        }else{
            k =  Float(p1! - f1!)
            kd = k
            performSegue(withIdentifier: "submittiaudiobuttonssegue", sender: Any?.self)
        }
        
        
    }
    
}
