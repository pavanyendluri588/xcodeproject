//
//  ViewController.swift
//  Jithendra
//
//  Created by Student on 27/10/23.
//  Copyright © 2023 lpu. All rights reserved.
//

import UIKit
import AVFoundation
var uname  = String()
var pass = String()
var f1 : Float?
var p1 : Float?
var k = Float()
var pdata = String()
class ViewController: UIViewController {
    var player : AVAudioPlayer  = AVAudioPlayer()
    override func viewDidLoad() {
        super.viewDidLoad()
       // img1.image = UIImage(named: "rj.jpg")
        // Do any additional setup after loading the view, typically from a nib.
//        do{
//            let audiopath = Bundle.main.path(forResource: "health", ofType: "mp3")
//            try player = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audiopath!) as URL)
//        }
//        catch{
//
//        }
        
        
        
    }
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        var s : newViewController = segue.destination as! newViewController
//        var n = u1.text
//        pdata = n!
//    }

    @IBOutlet weak var u1: UITextField!
    @IBOutlet weak var p1: UITextField!
    
    
    @IBAction func but(_ sender: Any) {
        uname = u1.text!
        pass = p1.text!
        pdata = u1.text!
      //player.play()
        
        if((uname == "sai" && pass == "123") || (uname == "sai@gmail.com" && pass == "1234")){
            
           performSegue(withIdentifier: "c1", sender: self)
            
            
        }else{
            view.backgroundColor = .red
            
            let alert1 = UIAlertController(title: "warning", message: "you entered a wrong password", preferredStyle: .actionSheet)
            alert1.addAction(UIAlertAction(title: "Once Try" , style: .default, handler: nil))
            alert1.addAction(UIAlertAction(title: "cancel", style: .default, handler: nil))
            self.present(alert1,animated: true,completion: nil)
        }
    }
    
    

   
    //@IBOutlet weak var img1: UIImageView!
}

