//
//  new1ViewController.swift
//  Jithendra
//
//  Created by Student on 27/10/23.
//  Copyright © 2023 lpu. All rights reserved.
//

import UIKit

class new1ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    
    @IBOutlet weak var d1: UITextField!
    
    
    @IBOutlet weak var signuppage_password_outlet: UITextField!
    
    
    
    @IBOutlet weak var signuppage_conform_password_outlet: UITextField!
    
    var siginpage_username:String = ""
    
    @IBAction func log(_ sender: Any) {
        siginpage_username = d1.text!
       
        if (signuppage_password_outlet.text! == signuppage_conform_password_outlet.text!){
            pdata = d1.text!
            performSegue(withIdentifier: "signuppagetowelcomepagesegue", sender: Any?.self)
        }else{
            let alert1 = UIAlertController(title: "Warning", message: "Enterd password and conformation password are wrong", preferredStyle: .alert)
            alert1.addAction(UIAlertAction(title: "cancel", style: .cancel, handler: nil))
            alert1.addAction(UIAlertAction(title: "ok", style: .default ,handler: nil))
                self.present(alert1,animated: true,completion: nil);
        }
        
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
