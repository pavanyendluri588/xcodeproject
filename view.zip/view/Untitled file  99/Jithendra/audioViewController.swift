//
//  audioViewController.swift
//  Jithendra
//
//  Created by Student on 27/10/23.
//  Copyright © 2023 lpu. All rights reserved.
//

import UIKit
import AVFoundation

class audioViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        
    }

    

}
