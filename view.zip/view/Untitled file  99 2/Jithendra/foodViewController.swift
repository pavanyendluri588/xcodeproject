//
//  foodViewController.swift
//  Jithendra
//
//  Created by pavan on 29/10/23.
//  Copyright © 2023 lpu. All rights reserved.
//


import UIKit
import AVFoundation


class foodViewController: UIViewController {
    var player : AVAudioPlayer = AVAudioPlayer()
    override func viewDidLoad() {
        
        super.viewDidLoad()
        lab1.text = String(kd)
        do {
            var audiopath = Bundle.main.path(forResource: "Food", ofType: "mp3")
            player = try AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audiopath!) as URL)
        }
        catch{
            print("error in shoping audio player")
        }
        
        player.play()
        
        
        
    }
    
    @IBOutlet weak var lab1: UILabel!
    
    

}
