//
//  donationViewController.swift
//  Jithendra
//
//  Created by pavan on 29/10/23.
//  Copyright © 2023 lpu. All rights reserved.
//

import UIKit
import AVFoundation
class donationViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        lab1.text = String(kd)
        do {
            var audiopath = Bundle.main.path(forResource: "Donation", ofType: "mp3")
            player = try AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audiopath!) as URL)
        }
        catch{
            print("error in shoping audio player")
        }
        
        player.play()
        
        
        // Do any additional setup after loading the view.
    }
    
    var player: AVAudioPlayer = AVAudioPlayer()

    
    @IBOutlet weak var lab1: UILabel!
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
